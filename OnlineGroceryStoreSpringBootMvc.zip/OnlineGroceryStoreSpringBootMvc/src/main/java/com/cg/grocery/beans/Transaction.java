package com.cg.grocery.beans;

import javax.persistence.Entity;

@Entity
public class Transaction {
	@Id
	@Generated
	private Long transactionId;
	private float totalPrice;
	}
